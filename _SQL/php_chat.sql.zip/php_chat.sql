-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 09, 2019 at 07:16 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `php_chat`
--

-- --------------------------------------------------------

--
-- Table structure for table `chat_message`
--

CREATE TABLE `chat_message` (
  `id` int(10) NOT NULL,
  `to_user_id` int(10) NOT NULL,
  `from_user_id` int(10) NOT NULL,
  `message` text NOT NULL,
  `is_seen` int(1) NOT NULL DEFAULT '0' COMMENT '0 = "Not Seen", 1 = "Seen"',
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `chat_message`
--

INSERT INTO `chat_message` (`id`, `to_user_id`, `from_user_id`, `message`, `is_seen`, `timestamp`) VALUES
(1, 3, 1, 'hello test', 0, '2019-07-18 11:10:36'),
(2, 1, 3, 'hello', 0, '2019-07-18 11:11:58'),
(3, 3, 1, '', 0, '2019-07-18 11:12:12'),
(4, 3, 1, 'helllo', 0, '2019-07-18 11:16:03'),
(5, 3, 1, 'hello', 0, '2019-07-18 11:16:28'),
(6, 1, 3, 'hello A', 0, '2019-07-18 11:16:37'),
(7, 3, 1, 'hello A', 0, '2019-07-18 11:16:55'),
(8, 3, 1, 'hello B', 0, '2019-07-18 11:17:05'),
(9, 1, 3, 'hello B', 0, '2019-07-18 11:17:14'),
(10, 3, 1, '', 0, '2019-07-18 11:17:23'),
(11, 3, 1, 'hello', 0, '2019-07-18 11:19:54'),
(12, 3, 1, 'hello A', 0, '2019-07-18 11:42:59'),
(13, 3, 1, '', 0, '2019-07-18 11:42:59'),
(14, 2, 3, 'hello', 1, '2019-07-24 12:18:49'),
(15, 2, 3, 'hello', 1, '2019-07-24 12:18:49'),
(16, 2, 3, '', 1, '2019-07-24 12:18:49'),
(17, 1, 3, '', 0, '2019-07-18 12:00:43'),
(18, 1, 3, 'hello', 0, '2019-07-18 12:09:15'),
(19, 1, 3, 'test ', 0, '2019-07-18 12:11:35'),
(20, 3, 1, 'test', 0, '2019-07-18 12:11:43'),
(21, 3, 2, 'test1', 0, '2019-07-19 03:47:37'),
(22, 2, 4, 'hello \njay shree krishna', 1, '2019-07-24 12:18:53'),
(23, 4, 2, 'hi jay shree krishan', 0, '2019-07-19 03:52:22'),
(25, 2, 7, 'hello', 1, '2019-07-24 12:19:07'),
(26, 7, 2, 'hello', 0, '2019-07-19 05:54:34'),
(29, 6, 2, 'ðŸ‡®ðŸ‡³ðŸ“•ðŸ“—ðŸ“˜ðŸ“™', 0, '2019-07-19 06:52:47'),
(30, 6, 2, '', 0, '2019-07-19 06:52:47'),
(31, 6, 2, '', 0, '2019-07-19 06:53:09'),
(32, 6, 2, '123\n456<br>456', 0, '2019-07-19 06:53:28'),
(34, 5, 2, 'hello ', 0, '2019-07-19 08:39:28');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(10) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `avtar_img` text NOT NULL,
  `status` int(1) NOT NULL COMMENT '0 = "Offline", 1 = "Online"',
  `is_typing` int(1) NOT NULL DEFAULT '0' COMMENT '0 = ''No'', 1 = ''Yes'''
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `name`, `email`, `password`, `avtar_img`, `status`, `is_typing`) VALUES
(1, 'test', 'test@gmail.com', '123456', '', 0, 0),
(2, 'admin', 'admin@gmail.com', '123456', '', 0, 0),
(3, 'testA', 'testA@gmail.com', '123456', '', 0, 0),
(4, 'userA', 'userA@gmail.com', '123456', '', 0, 0),
(5, 'userB', 'userB@gmail.com', '123456', '', 0, 0),
(6, 'userC', 'userC@gmail.com', '123456', '', 0, 0),
(7, 'userD', 'userD@gmail.com', '123456', '', 0, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `chat_message`
--
ALTER TABLE `chat_message`
  ADD PRIMARY KEY (`id`),
  ADD KEY `to_user_id` (`to_user_id`),
  ADD KEY `from_use_id` (`from_user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `chat_message`
--
ALTER TABLE `chat_message`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `chat_message`
--
ALTER TABLE `chat_message`
  ADD CONSTRAINT `chat_message_ibfk_1` FOREIGN KEY (`to_user_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `chat_message_ibfk_2` FOREIGN KEY (`from_user_id`) REFERENCES `users` (`user_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
